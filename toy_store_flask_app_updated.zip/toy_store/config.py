import os
import secrets
import warnings
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Значения, которые нельзя оставлять в боевом окружении — используются
# только для локальной разработки "из коробки".
_INSECURE_DEFAULT_ADMIN_PASSWORD = "admin123"


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


class Config:
    """Базовая конфигурация приложения."""

    # Признак боевого окружения. Влияет на строгость проверок ниже
    # и на настройки cookie (Secure требует HTTPS).
    ENV_IS_PRODUCTION = _env_bool("FLASK_PRODUCTION", False)

    # Секретный ключ для сессий и CSRF-токенов. В боевом окружении ОБЯЗАТЕЛЬНО
    # задавайте через переменную окружения SECRET_KEY — иначе все сессии
    # и CSRF-токены будут подделываемы и сброшены при каждом перезапуске.
    SECRET_KEY = os.environ.get("SECRET_KEY")
    if not SECRET_KEY:
        if ENV_IS_PRODUCTION:
            raise RuntimeError(
                "SECRET_KEY не задан. В боевом окружении (FLASK_PRODUCTION=true) "
                "запуск без переменной окружения SECRET_KEY запрещён."
            )
        warnings.warn(
            "SECRET_KEY не задан — используется случайный ключ, сгенерированный "
            "при старте (сессии и CSRF-токены будут сбрасываться при каждом "
            "перезапуске). Для разработки это нормально, но для боевого "
            "окружения задайте SECRET_KEY через переменную окружения.",
            RuntimeWarning,
        )
        SECRET_KEY = secrets.token_hex(32)

    # База данных — SQLite3, файл лежит рядом с приложением.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'store.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Логин/пароль по умолчанию для первого администратора (создаётся при
    # первом запуске, если в базе ещё нет ни одного пользователя).
    # ОБЯЗАТЕЛЬНО смените пароль сразу после первого входа.
    DEFAULT_ADMIN_USERNAME = os.environ.get("DEFAULT_ADMIN_USERNAME", "admin")
    DEFAULT_ADMIN_PASSWORD = os.environ.get(
        "DEFAULT_ADMIN_PASSWORD", _INSECURE_DEFAULT_ADMIN_PASSWORD
    )
    if ENV_IS_PRODUCTION and DEFAULT_ADMIN_PASSWORD == _INSECURE_DEFAULT_ADMIN_PASSWORD:
        raise RuntimeError(
            "DEFAULT_ADMIN_PASSWORD не задан. В боевом окружении запуск с паролем "
            "администратора по умолчанию ('admin123') запрещён."
        )

    # --- Cookies и сессии ---
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    # Secure-флаг работает только поверх HTTPS. Включайте на проде через
    # SESSION_COOKIE_SECURE=true (за обратным прокси с TLS).
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", ENV_IS_PRODUCTION)
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE

    # --- Прочие ограничения ---
    # Максимальный размер тела запроса (2 МБ) — защита от переполнения
    # памяти/диска через чрезмерно большие формы.
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024

    # Время жизни CSRF-токена совпадает со временем жизни сессии.
    WTF_CSRF_TIME_LIMIT = int(PERMANENT_SESSION_LIFETIME.total_seconds())
