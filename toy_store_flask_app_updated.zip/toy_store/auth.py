import time
from collections import defaultdict
from urllib.parse import urlparse

from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db
from models import User, ROLES

auth_bp = Blueprint("auth", __name__)

# --- Простая защита от перебора паролей ---------------------------------
# Хранит в памяти процесса количество неудачных попыток входа и время
# блокировки по паре (логин, IP). Для многопроцессного/многосерверного
# деплоя стоит заменить на Redis/Flask-Limiter, но для одного процесса
# этого достаточно, чтобы остановить простой автоматический перебор.
_LOGIN_ATTEMPT_LIMIT = 5
_LOGIN_LOCKOUT_SECONDS = 60
_failed_attempts = defaultdict(list)


def _login_rate_key():
    username = request.form.get("username", "").strip().lower()
    return f"{username}:{request.remote_addr}"


def _is_login_locked(key: str) -> bool:
    now = time.time()
    attempts = [t for t in _failed_attempts[key] if now - t < _LOGIN_LOCKOUT_SECONDS]
    _failed_attempts[key] = attempts
    return len(attempts) >= _LOGIN_ATTEMPT_LIMIT


def _register_failed_login(key: str) -> None:
    _failed_attempts[key].append(time.time())


def _clear_failed_login(key: str) -> None:
    _failed_attempts.pop(key, None)


def _is_safe_redirect_target(target: str) -> bool:
    """Разрешает редирект только на относительные пути внутри приложения,
    чтобы параметр ?next= нельзя было использовать для открытой переадресации."""
    if not target:
        return False
    parsed = urlparse(target)
    return not parsed.scheme and not parsed.netloc and target.startswith("/")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        rate_key = _login_rate_key()

        if _is_login_locked(rate_key):
            flash(
                "Слишком много неудачных попыток входа. Попробуйте снова через минуту.",
                "danger",
            )
            return render_template("login.html", username=username)

        user = User.query.filter_by(username=username).first()

        if user is None or not user.check_password(password):
            _register_failed_login(rate_key)
            flash("Неверный логин или пароль.", "danger")
            return render_template("login.html", username=username)

        if not user.is_active_flag:
            flash("Учётная запись отключена. Обратитесь к администратору.", "danger")
            return render_template("login.html", username=username)

        _clear_failed_login(rate_key)
        login_user(user)
        flash(f"Добро пожаловать, {user.full_name}!", "success")

        next_page = request.args.get("next")
        if not _is_safe_redirect_target(next_page):
            next_page = None
        return redirect(next_page or url_for("main.dashboard"))

    return render_template("login.html")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")

        errors = []
        if not username or len(username) < 3:
            errors.append("Логин должен содержать не менее 3 символов.")
        elif not username.replace("_", "").replace(".", "").isalnum():
            errors.append("Логин может содержать только буквы, цифры, «.» и «_».")
        if not full_name:
            errors.append("Укажите полное имя.")
        if len(password) < 8:
            errors.append("Пароль должен содержать не менее 8 символов.")
        elif not (any(c.isalpha() for c in password) and any(c.isdigit() for c in password)):
            errors.append("Пароль должен содержать как буквы, так и цифры.")
        if password != password_confirm:
            errors.append("Пароли не совпадают.")
        if username and User.query.filter_by(username=username).first() is not None:
            errors.append("Пользователь с таким логином уже существует.")

        if errors:
            for error in errors:
                flash(error, "danger")
            return render_template(
                "register.html", username=username, full_name=full_name
            )

        # Первый зарегистрированный сотрудник — по умолчанию кассир;
        # права/роль дальше настраивает администратор в разделе "Пользователи".
        user = User(username=username, full_name=full_name, role="cashier")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash("Регистрация прошла успешно. Теперь вы можете войти в систему.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("auth.login"))
