from flask import Flask
from flask_login import current_user

from config import Config
from extensions import db, login_manager
from models import User, Warehouse

from auth import auth_bp
from routes_main import main_bp
from routes_products import products_bp
from routes_warehouse import warehouse_bp
from routes_customers import customers_bp
from routes_suppliers import suppliers_bp
from routes_orders import orders_bp
from routes_reports import reports_bp
from routes_admin import admin_bp


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(products_bp)
    app.register_blueprint(warehouse_bp)
    app.register_blueprint(customers_bp)
    app.register_blueprint(suppliers_bp)
    app.register_blueprint(orders_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(admin_bp)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @app.context_processor
    def inject_globals():
        return {"current_user": current_user}

    with app.app_context():
        db.create_all()
        _seed_initial_data(app)

    return app


def _seed_initial_data(app):
    """Создаёт администратора по умолчанию и базовый склад при первом запуске."""
    if User.query.count() == 0:
        admin = User(
            username=app.config["DEFAULT_ADMIN_USERNAME"],
            full_name="Администратор системы",
            role="admin",
        )
        admin.set_password(app.config["DEFAULT_ADMIN_PASSWORD"])
        db.session.add(admin)

    if Warehouse.query.count() == 0:
        db.session.add(Warehouse(name="Основной склад"))

    db.session.commit()


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
