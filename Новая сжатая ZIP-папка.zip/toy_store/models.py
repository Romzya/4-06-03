from datetime import datetime

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db

# ---------------------------------------------------------------------------
# Пользователи и роли (администрирование и права доступа)
# ---------------------------------------------------------------------------

ROLES = {
    "admin": "Администратор",
    "manager": "Менеджер (ассортимент/закупки)",
    "cashier": "Кассир (заказы)",
    "warehouse": "Кладовщик (склад)",
}


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(128), nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="cashier")
    is_active_flag = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    @property
    def role_label(self) -> str:
        return ROLES.get(self.role, self.role)

    @property
    def is_active(self):  # noqa: D401 - переопределение свойства flask-login
        return self.is_active_flag

    def __repr__(self):
        return f"<User {self.username} ({self.role})>"


# ---------------------------------------------------------------------------
# Подсистема "Номенклатура и цены"
# ---------------------------------------------------------------------------

class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True, nullable=False)

    products = db.relationship("Product", backref="category", lazy=True)

    def __repr__(self):
        return f"<Category {self.name}>"


class Product(db.Model):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    barcode = db.Column(db.String(64), unique=True, nullable=True)
    price = db.Column(db.Float, nullable=False, default=0.0)
    description = db.Column(db.Text, nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    stocks = db.relationship("Stock", backref="product", lazy=True, cascade="all, delete-orphan")

    @property
    def total_quantity(self) -> int:
        return sum(s.quantity for s in self.stocks)

    def generate_barcode(self) -> str:
        """Генерация внутреннего штрих-кода, если он отсутствует (п.4.1.4 ТЗ)."""
        return f"200{self.id:010d}"

    def __repr__(self):
        return f"<Product {self.name}>"


# ---------------------------------------------------------------------------
# Подсистема "Складской учёт"
# ---------------------------------------------------------------------------

class Warehouse(db.Model):
    __tablename__ = "warehouses"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True, nullable=False)

    stocks = db.relationship("Stock", backref="warehouse", lazy=True, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Warehouse {self.name}>"


class Stock(db.Model):
    """Остаток конкретного товара на конкретном складе."""

    __tablename__ = "stocks"
    __table_args__ = (db.UniqueConstraint("product_id", "warehouse_id", name="uq_product_warehouse"),)

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    warehouse_id = db.Column(db.Integer, db.ForeignKey("warehouses.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=0)
    min_quantity = db.Column(db.Integer, nullable=False, default=0)  # порог для заявки на пополнение

    @property
    def is_low(self) -> bool:
        return self.quantity <= self.min_quantity


# ---------------------------------------------------------------------------
# Подсистема "Поставщики и закупки"
# ---------------------------------------------------------------------------

class Supplier(db.Model):
    __tablename__ = "suppliers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    contact_person = db.Column(db.String(128), nullable=True)
    phone = db.Column(db.String(32), nullable=True)
    email = db.Column(db.String(128), nullable=True)

    purchase_orders = db.relationship("PurchaseOrder", backref="supplier", lazy=True)

    def __repr__(self):
        return f"<Supplier {self.name}>"


PURCHASE_STATUSES = {
    "new": "Новая",
    "sent": "Отправлена поставщику",
    "received": "Товар получен",
    "cancelled": "Отменена",
}


class PurchaseOrder(db.Model):
    """Заявка на пополнение товара поставщику."""

    __tablename__ = "purchase_orders"

    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="new")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    items = db.relationship("PurchaseOrderItem", backref="purchase_order", lazy=True, cascade="all, delete-orphan")
    created_by = db.relationship("User")

    @property
    def total(self) -> float:
        return sum(item.quantity * item.price for item in self.items)

    @property
    def status_label(self) -> str:
        return PURCHASE_STATUSES.get(self.status, self.status)


class PurchaseOrderItem(db.Model):
    __tablename__ = "purchase_order_items"

    id = db.Column(db.Integer, primary_key=True)
    purchase_order_id = db.Column(db.Integer, db.ForeignKey("purchase_orders.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    price = db.Column(db.Float, nullable=False, default=0.0)

    product = db.relationship("Product")


# ---------------------------------------------------------------------------
# Подсистема "Работа с клиентами" / программа лояльности
# ---------------------------------------------------------------------------

class Customer(db.Model):
    __tablename__ = "customers"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(32), unique=True, nullable=True)
    email = db.Column(db.String(128), nullable=True)
    bonus_points = db.Column(db.Integer, nullable=False, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    orders = db.relationship("Order", backref="customer", lazy=True)

    def __repr__(self):
        return f"<Customer {self.full_name}>"


# ---------------------------------------------------------------------------
# Подсистема "Онлайн заказ"
# ---------------------------------------------------------------------------

ORDER_STATUSES = {
    "new": "Новый",
    "processing": "В обработке",
    "paid": "Оплачен",
    "completed": "Выполнен",
    "cancelled": "Отменён",
}


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="new")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    bonus_used = db.Column(db.Integer, nullable=False, default=0)

    items = db.relationship("OrderItem", backref="order", lazy=True, cascade="all, delete-orphan")
    created_by = db.relationship("User")

    @property
    def total(self) -> float:
        return sum(item.quantity * item.price for item in self.items) - self.bonus_used

    @property
    def status_label(self) -> str:
        return ORDER_STATUSES.get(self.status, self.status)


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    price = db.Column(db.Float, nullable=False, default=0.0)

    product = db.relationship("Product")
