from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from extensions import db
from models import Order, OrderItem, Product, Customer, Stock, ORDER_STATUSES
from utils import roles_required

orders_bp = Blueprint("orders", __name__, url_prefix="/orders")


@orders_bp.route("/")
@login_required
@roles_required("cashier", "manager")
def list_orders():
    status = request.args.get("status")
    query = Order.query
    if status:
        query = query.filter_by(status=status)
    orders = query.order_by(Order.created_at.desc()).all()
    return render_template("orders/list.html", orders=orders, status=status, statuses=ORDER_STATUSES)


@orders_bp.route("/add", methods=["GET", "POST"])
@login_required
@roles_required("cashier", "manager")
def add_order():
    customers = Customer.query.order_by(Customer.full_name).all()
    products = Product.query.order_by(Product.name).all()

    if request.method == "POST":
        customer_id = request.form.get("customer_id", type=int) or None
        bonus_used = request.form.get("bonus_used", type=int, default=0) or 0

        order = Order(customer_id=customer_id, created_by_id=current_user.id, bonus_used=bonus_used)
        db.session.add(order)
        db.session.flush()

        product_ids = request.form.getlist("product_id")
        quantities = request.form.getlist("quantity")

        added_any = False
        for pid, qty in zip(product_ids, quantities):
            if not pid or not qty:
                continue
            product = Product.query.get(int(pid))
            if not product:
                continue
            item = OrderItem(
                order_id=order.id,
                product_id=product.id,
                quantity=int(qty),
                price=product.price,
            )
            db.session.add(item)
            added_any = True

            # Списываем товар с первого найденного склада, где он есть.
            stock = Stock.query.filter_by(product_id=product.id).first()
            if stock:
                stock.quantity = max(0, stock.quantity - int(qty))

        if not added_any:
            db.session.rollback()
            flash("Добавьте хотя бы один товар в заказ.", "danger")
            return render_template("orders/form.html", customers=customers, products=products)

        # Списываем использованные бонусы клиента.
        if customer_id and bonus_used:
            customer = Customer.query.get(customer_id)
            if customer:
                customer.bonus_points = max(0, customer.bonus_points - bonus_used)

        db.session.commit()
        flash(f"Заказ №{order.id} создан.", "success")
        return redirect(url_for("orders.list_orders"))

    return render_template("orders/form.html", customers=customers, products=products)


@orders_bp.route("/<int:order_id>")
@login_required
@roles_required("cashier", "manager")
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template("orders/detail.html", order=order, statuses=ORDER_STATUSES)


@orders_bp.route("/<int:order_id>/status", methods=["POST"])
@login_required
@roles_required("cashier", "manager")
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get("status")

    if new_status not in ORDER_STATUSES:
        flash("Некорректный статус.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order.id))

    # Начисляем бонусы (5% от суммы) при завершении заказа — программа лояльности.
    if new_status == "completed" and order.status != "completed" and order.customer_id:
        customer = Customer.query.get(order.customer_id)
        if customer:
            customer.bonus_points += int(order.total * 0.05)

    order.status = new_status
    db.session.commit()
    flash(f"Статус заказа №{order.id} обновлён: {order.status_label}.", "success")
    return redirect(url_for("orders.order_detail", order_id=order.id))
