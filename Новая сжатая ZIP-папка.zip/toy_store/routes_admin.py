from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from extensions import db
from models import User, ROLES
from utils import roles_required

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/users")
@login_required
@roles_required("admin")
def list_users():
    users = User.query.order_by(User.username).all()
    return render_template("admin/users.html", users=users, roles=ROLES)


@admin_bp.route("/users/<int:user_id>/role", methods=["POST"])
@login_required
@roles_required("admin")
def change_role(user_id):
    user = User.query.get_or_404(user_id)
    new_role = request.form.get("role")

    if new_role not in ROLES:
        flash("Некорректная роль.", "danger")
        return redirect(url_for("admin.list_users"))

    user.role = new_role
    db.session.commit()
    flash(f"Роль пользователя {user.username} изменена на «{user.role_label}».", "success")
    return redirect(url_for("admin.list_users"))


@admin_bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@roles_required("admin")
def toggle_active(user_id):
    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash("Нельзя заблокировать собственную учётную запись.", "danger")
        return redirect(url_for("admin.list_users"))

    user.is_active_flag = not user.is_active_flag
    db.session.commit()
    state = "активирован" if user.is_active_flag else "заблокирован"
    flash(f"Пользователь {user.username} {state}.", "info")
    return redirect(url_for("admin.list_users"))
