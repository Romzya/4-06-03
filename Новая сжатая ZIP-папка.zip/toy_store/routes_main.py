from flask import Blueprint, render_template
from flask_login import login_required, current_user

from models import Product, Customer, Order, PurchaseOrder, Stock

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
@login_required
def dashboard():
    stats = {
        "products_count": Product.query.count(),
        "customers_count": Customer.query.count(),
        "orders_new": Order.query.filter_by(status="new").count(),
        "purchase_open": PurchaseOrder.query.filter(
            PurchaseOrder.status.in_(["new", "sent"])
        ).count(),
    }
    low_stock = [s for s in Stock.query.all() if s.is_low]
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()

    return render_template(
        "dashboard.html",
        stats=stats,
        low_stock=low_stock[:10],
        recent_orders=recent_orders,
    )
