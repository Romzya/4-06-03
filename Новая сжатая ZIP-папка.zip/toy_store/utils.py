from functools import wraps

from flask import abort
from flask_login import current_user


def roles_required(*roles):
    """Декоратор, ограничивающий доступ к маршруту по ролям пользователя.

    Администратор ("admin") имеет доступ ко всем разделам системы всегда.
    """

    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role == "admin" or current_user.role in roles:
                return view_func(*args, **kwargs)
            abort(403)

        return wrapped

    return decorator
