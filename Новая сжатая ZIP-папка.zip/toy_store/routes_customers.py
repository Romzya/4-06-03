from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required

from extensions import db
from models import Customer
from utils import roles_required

customers_bp = Blueprint("customers", __name__, url_prefix="/customers")


@customers_bp.route("/")
@login_required
def list_customers():
    query = request.args.get("q", "").strip()
    customers_query = Customer.query
    if query:
        customers_query = customers_query.filter(
            db.or_(
                Customer.full_name.ilike(f"%{query}%"),
                Customer.phone.ilike(f"%{query}%"),
            )
        )
    customers = customers_query.order_by(Customer.full_name).all()
    return render_template("customers/list.html", customers=customers, query=query)


@customers_bp.route("/add", methods=["GET", "POST"])
@login_required
@roles_required("manager", "cashier")
def add_customer():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip() or None
        email = request.form.get("email", "").strip() or None

        if not full_name:
            flash("Укажите ФИО клиента.", "danger")
            return render_template("customers/form.html", customer=None)

        customer = Customer(full_name=full_name, phone=phone, email=email)
        db.session.add(customer)
        db.session.commit()
        flash(f'Клиент "{customer.full_name}" добавлен.', "success")
        return redirect(url_for("customers.list_customers"))

    return render_template("customers/form.html", customer=None)


@customers_bp.route("/<int:customer_id>/edit", methods=["GET", "POST"])
@login_required
@roles_required("manager", "cashier")
def edit_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)

    if request.method == "POST":
        customer.full_name = request.form.get("full_name", "").strip() or customer.full_name
        customer.phone = request.form.get("phone", "").strip() or None
        customer.email = request.form.get("email", "").strip() or None
        db.session.commit()
        flash(f'Данные клиента "{customer.full_name}" обновлены.', "success")
        return redirect(url_for("customers.list_customers"))

    return render_template("customers/form.html", customer=customer)


@customers_bp.route("/<int:customer_id>/bonus", methods=["POST"])
@login_required
@roles_required("manager", "cashier")
def adjust_bonus(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    action = request.form.get("action")
    amount = request.form.get("amount", type=int, default=0) or 0

    if action == "add":
        customer.bonus_points += amount
    elif action == "remove":
        customer.bonus_points = max(0, customer.bonus_points - amount)

    db.session.commit()
    flash(f"Баланс бонусов клиента {customer.full_name}: {customer.bonus_points}.", "success")
    return redirect(url_for("customers.list_customers"))


@customers_bp.route("/<int:customer_id>/delete", methods=["POST"])
@login_required
@roles_required("manager")
def delete_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    db.session.delete(customer)
    db.session.commit()
    flash(f'Клиент "{customer.full_name}" удалён.', "info")
    return redirect(url_for("customers.list_customers"))
