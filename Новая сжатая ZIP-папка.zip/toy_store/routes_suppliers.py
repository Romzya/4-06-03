from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from extensions import db
from models import Supplier, PurchaseOrder, PurchaseOrderItem, Product, Stock, PURCHASE_STATUSES
from utils import roles_required

suppliers_bp = Blueprint("suppliers", __name__, url_prefix="/suppliers")


@suppliers_bp.route("/")
@login_required
@roles_required("manager", "warehouse")
def list_suppliers():
    suppliers = Supplier.query.order_by(Supplier.name).all()
    return render_template("suppliers/list.html", suppliers=suppliers)


@suppliers_bp.route("/add", methods=["GET", "POST"])
@login_required
@roles_required("manager")
def add_supplier():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Укажите название поставщика.", "danger")
            return render_template("suppliers/form.html", supplier=None)

        supplier = Supplier(
            name=name,
            contact_person=request.form.get("contact_person", "").strip(),
            phone=request.form.get("phone", "").strip(),
            email=request.form.get("email", "").strip(),
        )
        db.session.add(supplier)
        db.session.commit()
        flash(f'Поставщик "{supplier.name}" добавлен.', "success")
        return redirect(url_for("suppliers.list_suppliers"))

    return render_template("suppliers/form.html", supplier=None)


@suppliers_bp.route("/<int:supplier_id>/edit", methods=["GET", "POST"])
@login_required
@roles_required("manager")
def edit_supplier(supplier_id):
    supplier = Supplier.query.get_or_404(supplier_id)
    if request.method == "POST":
        supplier.name = request.form.get("name", "").strip() or supplier.name
        supplier.contact_person = request.form.get("contact_person", "").strip()
        supplier.phone = request.form.get("phone", "").strip()
        supplier.email = request.form.get("email", "").strip()
        db.session.commit()
        flash(f'Данные поставщика "{supplier.name}" обновлены.', "success")
        return redirect(url_for("suppliers.list_suppliers"))

    return render_template("suppliers/form.html", supplier=supplier)


@suppliers_bp.route("/<int:supplier_id>/delete", methods=["POST"])
@login_required
@roles_required("manager")
def delete_supplier(supplier_id):
    supplier = Supplier.query.get_or_404(supplier_id)
    db.session.delete(supplier)
    db.session.commit()
    flash(f'Поставщик "{supplier.name}" удалён.', "info")
    return redirect(url_for("suppliers.list_suppliers"))


# --- Заявки на пополнение (закупки) ---

@suppliers_bp.route("/purchase-orders")
@login_required
@roles_required("manager", "warehouse")
def list_purchase_orders():
    orders = PurchaseOrder.query.order_by(PurchaseOrder.created_at.desc()).all()
    return render_template("purchases/list.html", orders=orders)


@suppliers_bp.route("/purchase-orders/add", methods=["GET", "POST"])
@login_required
@roles_required("manager", "warehouse")
def add_purchase_order():
    suppliers = Supplier.query.order_by(Supplier.name).all()
    products = Product.query.order_by(Product.name).all()

    if request.method == "POST":
        supplier_id = request.form.get("supplier_id", type=int)
        if not supplier_id:
            flash("Выберите поставщика.", "danger")
            return render_template("purchases/form.html", suppliers=suppliers, products=products)

        order = PurchaseOrder(supplier_id=supplier_id, created_by_id=current_user.id)
        db.session.add(order)
        db.session.flush()

        product_ids = request.form.getlist("product_id")
        quantities = request.form.getlist("quantity")
        prices = request.form.getlist("price")

        added_any = False
        for pid, qty, price in zip(product_ids, quantities, prices):
            if not pid or not qty:
                continue
            item = PurchaseOrderItem(
                purchase_order_id=order.id,
                product_id=int(pid),
                quantity=int(qty),
                price=float(price) if price else 0.0,
            )
            db.session.add(item)
            added_any = True

        if not added_any:
            db.session.rollback()
            flash("Добавьте хотя бы одну позицию в заявку.", "danger")
            return render_template("purchases/form.html", suppliers=suppliers, products=products)

        db.session.commit()
        flash(f"Заявка поставщику №{order.id} создана.", "success")
        return redirect(url_for("suppliers.list_purchase_orders"))

    return render_template("purchases/form.html", suppliers=suppliers, products=products)


@suppliers_bp.route("/purchase-orders/<int:order_id>/status", methods=["POST"])
@login_required
@roles_required("manager", "warehouse")
def update_purchase_status(order_id):
    order = PurchaseOrder.query.get_or_404(order_id)
    new_status = request.form.get("status")

    if new_status not in PURCHASE_STATUSES:
        flash("Некорректный статус.", "danger")
        return redirect(url_for("suppliers.list_purchase_orders"))

    # При получении товара автоматически пополняем остатки на первом складе.
    if new_status == "received" and order.status != "received":
        for item in order.items:
            stock = Stock.query.filter_by(product_id=item.product_id).first()
            if stock:
                stock.quantity += item.quantity

    order.status = new_status
    db.session.commit()
    flash(f"Статус заявки №{order.id} обновлён: {order.status_label}.", "success")
    return redirect(url_for("suppliers.list_purchase_orders"))
