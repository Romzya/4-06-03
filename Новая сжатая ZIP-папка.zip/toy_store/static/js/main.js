// Подтверждение удаления для форм с атрибутом data-confirm.
document.addEventListener("submit", function (event) {
  const form = event.target;
  if (form.hasAttribute("data-confirm")) {
    const message = form.getAttribute("data-confirm") || "Вы уверены?";
    if (!window.confirm(message)) {
      event.preventDefault();
    }
  }
});

// Автоматическое скрытие flash-сообщений через 5 секунд.
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".flash").forEach(function (el) {
    setTimeout(function () {
      el.style.transition = "opacity 0.4s ease";
      el.style.opacity = "0";
      setTimeout(function () {
        el.remove();
      }, 400);
    }, 5000);
  });
});

/**
 * Добавляет новую строку выбора товара в форму заказа/заявки поставщику.
 * Ожидает контейнер с id="order-items" и шаблон строки в <template id="order-item-template">.
 */
function addOrderItemRow() {
  const container = document.getElementById("order-items");
  const template = document.getElementById("order-item-template");
  if (!container || !template) return;

  const clone = template.content.cloneNode(true);
  container.appendChild(clone);
}

document.addEventListener("DOMContentLoaded", function () {
  const addBtn = document.getElementById("add-item-row-btn");
  if (addBtn) {
    addBtn.addEventListener("click", addOrderItemRow);
  }

  // Удаление строки товара по кнопке внутри строки.
  document.addEventListener("click", function (event) {
    if (event.target.matches(".remove-item-row")) {
      const row = event.target.closest(".order-items-row");
      if (row) row.remove();
    }
  });
});
