from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required

from extensions import db
from models import Product, Category, Warehouse, Stock
from utils import roles_required

products_bp = Blueprint("products", __name__, url_prefix="/products")


@products_bp.route("/")
@login_required
def list_products():
    query = request.args.get("q", "").strip()
    category_id = request.args.get("category_id", type=int)

    products_query = Product.query
    if query:
        products_query = products_query.filter(Product.name.ilike(f"%{query}%"))
    if category_id:
        products_query = products_query.filter_by(category_id=category_id)

    products = products_query.order_by(Product.name).all()
    categories = Category.query.order_by(Category.name).all()

    return render_template(
        "products/list.html",
        products=products,
        categories=categories,
        query=query,
        category_id=category_id,
    )


@products_bp.route("/add", methods=["GET", "POST"])
@login_required
@roles_required("manager")
def add_product():
    categories = Category.query.order_by(Category.name).all()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        price = request.form.get("price", type=float, default=0.0)
        barcode = request.form.get("barcode", "").strip() or None
        category_id = request.form.get("category_id", type=int)
        description = request.form.get("description", "").strip()

        if not name:
            flash("Укажите наименование товара.", "danger")
            return render_template("products/form.html", categories=categories, product=None)

        product = Product(
            name=name,
            price=price or 0.0,
            barcode=barcode,
            category_id=category_id,
            description=description,
        )
        db.session.add(product)
        db.session.commit()

        if not product.barcode:
            product.barcode = product.generate_barcode()
            db.session.commit()

        # Создаём нулевые остатки на всех существующих складах.
        for warehouse in Warehouse.query.all():
            db.session.add(Stock(product_id=product.id, warehouse_id=warehouse.id, quantity=0))
        db.session.commit()

        flash(f'Товар "{product.name}" добавлен.', "success")
        return redirect(url_for("products.list_products"))

    return render_template("products/form.html", categories=categories, product=None)


@products_bp.route("/<int:product_id>/edit", methods=["GET", "POST"])
@login_required
@roles_required("manager")
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    categories = Category.query.order_by(Category.name).all()

    if request.method == "POST":
        product.name = request.form.get("name", "").strip() or product.name
        product.price = request.form.get("price", type=float, default=product.price)
        product.barcode = request.form.get("barcode", "").strip() or product.barcode
        product.category_id = request.form.get("category_id", type=int)
        product.description = request.form.get("description", "").strip()

        db.session.commit()
        flash(f'Товар "{product.name}" обновлён.', "success")
        return redirect(url_for("products.list_products"))

    return render_template("products/form.html", categories=categories, product=product)


@products_bp.route("/<int:product_id>/delete", methods=["POST"])
@login_required
@roles_required("manager")
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash(f'Товар "{product.name}" удалён.', "info")
    return redirect(url_for("products.list_products"))


# --- Категории ---

@products_bp.route("/categories", methods=["GET", "POST"])
@login_required
@roles_required("manager")
def categories():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name and not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name))
            db.session.commit()
            flash(f'Категория "{name}" добавлена.', "success")
        else:
            flash("Категория с таким названием уже существует или имя пустое.", "danger")
        return redirect(url_for("products.categories"))

    all_categories = Category.query.order_by(Category.name).all()
    return render_template("products/categories.html", categories=all_categories)


@products_bp.route("/categories/<int:category_id>/delete", methods=["POST"])
@login_required
@roles_required("manager")
def delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    db.session.delete(category)
    db.session.commit()
    flash(f'Категория "{category.name}" удалена.', "info")
    return redirect(url_for("products.categories"))
