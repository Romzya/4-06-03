from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db
from models import User, ROLES

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = User.query.filter_by(username=username).first()

        if user is None or not user.check_password(password):
            flash("Неверный логин или пароль.", "danger")
            return render_template("login.html", username=username)

        if not user.is_active_flag:
            flash("Учётная запись отключена. Обратитесь к администратору.", "danger")
            return render_template("login.html", username=username)

        login_user(user)
        flash(f"Добро пожаловать, {user.full_name}!", "success")

        next_page = request.args.get("next")
        return redirect(next_page or url_for("main.dashboard"))

    return render_template("login.html")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")

        errors = []
        if not username or len(username) < 3:
            errors.append("Логин должен содержать не менее 3 символов.")
        if not full_name:
            errors.append("Укажите полное имя.")
        if len(password) < 6:
            errors.append("Пароль должен содержать не менее 6 символов.")
        if password != password_confirm:
            errors.append("Пароли не совпадают.")
        if User.query.filter_by(username=username).first() is not None:
            errors.append("Пользователь с таким логином уже существует.")

        if errors:
            for error in errors:
                flash(error, "danger")
            return render_template(
                "register.html", username=username, full_name=full_name
            )

        # Первый зарегистрированный сотрудник — по умолчанию кассир;
        # права/роль дальше настраивает администратор в разделе "Пользователи".
        user = User(username=username, full_name=full_name, role="cashier")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash("Регистрация прошла успешно. Теперь вы можете войти в систему.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("auth.login"))
