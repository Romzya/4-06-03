from flask import Blueprint, render_template
from flask_login import login_required
from sqlalchemy import func

from extensions import db
from models import OrderItem, Product, Order, Stock, Customer
from utils import roles_required

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")


@reports_bp.route("/")
@login_required
@roles_required("manager")
def index():
    # Выручка и продажи по товарам.
    sales_by_product = (
        db.session.query(
            Product.name,
            func.sum(OrderItem.quantity).label("qty"),
            func.sum(OrderItem.quantity * OrderItem.price).label("revenue"),
        )
        .join(OrderItem, OrderItem.product_id == Product.id)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.status != "cancelled")
        .group_by(Product.id)
        .order_by(func.sum(OrderItem.quantity * OrderItem.price).desc())
        .all()
    )

    total_revenue = sum(row.revenue or 0 for row in sales_by_product)
    orders_count = Order.query.filter(Order.status != "cancelled").count()

    # Остатки по складам.
    low_stock = [s for s in Stock.query.join(Product).order_by(Product.name).all() if s.is_low]

    # Топ клиентов по бонусам.
    top_customers = Customer.query.order_by(Customer.bonus_points.desc()).limit(5).all()

    return render_template(
        "reports/index.html",
        sales_by_product=sales_by_product,
        total_revenue=total_revenue,
        orders_count=orders_count,
        low_stock=low_stock,
        top_customers=top_customers,
    )
