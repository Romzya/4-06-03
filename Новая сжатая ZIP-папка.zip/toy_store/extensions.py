from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# Единые экземпляры расширений, используемые во всём приложении.
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Пожалуйста, войдите в систему для доступа к этой странице."
login_manager.login_message_category = "warning"
