import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Базовая конфигурация приложения."""

    # Секретный ключ для сессий и CSRF. В боевом окружении задавайте
    # через переменную окружения SECRET_KEY.
    SECRET_KEY = os.environ.get("SECRET_KEY", "toy-store-dev-secret-key")

    # База данных — SQLite3, файл лежит рядом с приложением.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'store.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Логин по умолчанию для первого администратора (создаётся при первом
    # запуске, если в базе ещё нет ни одного пользователя).
    DEFAULT_ADMIN_USERNAME = os.environ.get("DEFAULT_ADMIN_USERNAME", "admin")
    DEFAULT_ADMIN_PASSWORD = os.environ.get("DEFAULT_ADMIN_PASSWORD", "admin123")
