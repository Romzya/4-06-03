from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required

from extensions import db
from models import Warehouse, Stock, Product
from utils import roles_required

warehouse_bp = Blueprint("warehouse", __name__, url_prefix="/warehouse")


@warehouse_bp.route("/")
@login_required
@roles_required("warehouse", "manager")
def stock_list():
    warehouse_id = request.args.get("warehouse_id", type=int)
    only_low = request.args.get("only_low") == "1"

    query = Stock.query
    if warehouse_id:
        query = query.filter_by(warehouse_id=warehouse_id)

    stocks = query.join(Product).order_by(Product.name).all()
    if only_low:
        stocks = [s for s in stocks if s.is_low]

    warehouses = Warehouse.query.order_by(Warehouse.name).all()

    return render_template(
        "warehouse/list.html",
        stocks=stocks,
        warehouses=warehouses,
        warehouse_id=warehouse_id,
        only_low=only_low,
    )


@warehouse_bp.route("/stock/<int:stock_id>/adjust", methods=["GET", "POST"])
@login_required
@roles_required("warehouse", "manager")
def adjust_stock(stock_id):
    stock = Stock.query.get_or_404(stock_id)

    if request.method == "POST":
        action = request.form.get("action")
        amount = request.form.get("amount", type=int, default=0) or 0
        min_quantity = request.form.get("min_quantity", type=int)

        if action == "add":
            stock.quantity += amount
        elif action == "remove":
            stock.quantity = max(0, stock.quantity - amount)
        elif action == "set":
            stock.quantity = max(0, amount)

        if min_quantity is not None:
            stock.min_quantity = max(0, min_quantity)

        db.session.commit()
        flash(f'Остаток товара "{stock.product.name}" обновлён.', "success")
        return redirect(url_for("warehouse.stock_list"))

    return render_template("warehouse/adjust.html", stock=stock)


# --- Управление складами ---

@warehouse_bp.route("/list", methods=["GET", "POST"])
@login_required
@roles_required("warehouse", "manager")
def warehouses():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name and not Warehouse.query.filter_by(name=name).first():
            new_warehouse = Warehouse(name=name)
            db.session.add(new_warehouse)
            db.session.commit()

            # Заводим нулевые остатки для всех существующих товаров.
            for product in Product.query.all():
                db.session.add(Stock(product_id=product.id, warehouse_id=new_warehouse.id, quantity=0))
            db.session.commit()

            flash(f'Склад "{name}" добавлен.', "success")
        else:
            flash("Склад с таким названием уже существует или имя пустое.", "danger")
        return redirect(url_for("warehouse.warehouses"))

    all_warehouses = Warehouse.query.order_by(Warehouse.name).all()
    return render_template("warehouse/warehouses.html", warehouses=all_warehouses)


@warehouse_bp.route("/list/<int:warehouse_id>/delete", methods=["POST"])
@login_required
@roles_required("manager")
def delete_warehouse(warehouse_id):
    warehouse = Warehouse.query.get_or_404(warehouse_id)
    db.session.delete(warehouse)
    db.session.commit()
    flash(f'Склад "{warehouse.name}" удалён.', "info")
    return redirect(url_for("warehouse.warehouses"))
